var hrInduction = function(){
    var _this = this;

    this.init = function(){
        console.log("Init function invoked");
        _this.isCorrectlyDropped = false;
        _this.dropCount = 0;
        _this.correctDrop = 0;
        _this.inCorrectDrop = 0;
        _this.getJsonData();
    }

    this.getJsonData = function(){
        $.ajax({
            url : "assets/data/data.json",
            type : "GET",
            cache : false,
            success : _this.loadSuccess,
            error : _this.onLoadError
        });
    }

    this.loadSuccess = function(jdata){
        console.log("Json loaded successfully");
        _this.jsonData = jdata.data;
        console.log(_this.jsonData);
        _this.initStickyNotes();
    }

    this.onLoadError = function(){
        console.log("Error on load json data");
    }

    this.initStickyNotes = function(){
        console.log(_this.jsonData.dragData.length);

        for(let i=0; i<_this.jsonData.dragData.length; i++){
            $(".itemsHolder").append("<div><div  noteType="+_this.jsonData.dragData[i].category+" id=item"+_this.jsonData.dragData[i].id+" class='dragItems'>"+_this.jsonData.dragData[i].text+"</div></div>");
            $('#item'+_this.jsonData.dragData[i].id).css({
                "background": "url("+_this.jsonData.commonImagePath+_this.jsonData.dragData[i].bgImage+") no-repeat",
                "background-size" : "112% 88%",
                "background-position" : "-5px -8px",
            });
            $("#item"+_this.jsonData.dragData[i].id).addClass("changeStickyNote");
        }

        for(let i=0; i<_this.jsonData.dropData.length; i++){
            //$(".binsContainer").append("<img class='bins' binType="+_this.jsonData.dropData[i].type+" src="+_this.jsonData.commonImagePath+_this.jsonData.dropData[i].image+" alt="+_this.jsonData.dropData[i].type+">")
            $(".binsContainer").append("<div class='bins' id=bay"+_this.jsonData.dropData[i].id+" binType="+_this.jsonData.dropData[i].type+"></div>");
            $("#bay"+_this.jsonData.dropData[i].id).css({
                "background" : "url("+_this.jsonData.commonImagePath+_this.jsonData.dropData[i].image+")",
                "background-size" : "100% 100%"
            });
        }

        $(".bins").addClass("bin");

        _this.addEvents();
    }

    this.addEvents = function(){
        $(".dragItems").draggable({
            appendTo: "body",
            containment : $('.DDcontainer'),
            start: function(){
                _this.isCorrectlyDropped = false;
            },
            stop : function(){
                _this.checkDestination(this);
                if(_this.isCorrectlyDropped){
                    console.log('Valid Drop');	
				}else{
					console.log('Invalid Drop');
				}
            }
        });

        this.checkDestination = function(currentItem){
            $(currentItem).css({
                "position" : "relative",
                "top" : "0",
                "left" : "0",
                "right" : "0",
                "bottom" : "0",
            })
        }

        $(".bins").droppable({
            drop: function(event, ui){
                _this.isCorrectlyDropped = true;
                _this.currentDragElem = $(ui.draggable);
                _this.currentDropElem = $(this);
                _this.checkBin(_this.currentDragElem,_this.currentDropElem);
            }
        });
    }

    this.checkBin = function(curDragElement,curDropElement){
        _this.dropCount++;
        _this.noteType = $(curDragElement).attr('noteType');
        _this.binType = $(curDropElement).attr('binType');
        $(curDropElement).append($(curDragElement));
        $(curDragElement).addClass("hideContent");

        if(_this.noteType == _this.binType){
            console.log("Correctly Placed");
            _this.correctDrop++;
        }else{
            console.log("Incorrectly placed");
            _this.inCorrectDrop++;
        }
        console.log("Drop count",_this.dropCount);
        if(_this.dropCount == _this.jsonData.dragData.length){
            alert("Bin closed: corrctly Placed = "+_this.correctDrop+" Incorrctly Placed = "+_this.inCorrectDrop);
        }
    }
}